// execute callback when the page is ready:
    Zepto(function($){
      console.log('Ready to Zepto!');

      $.getJSON('/parametros', function(response){
        console.log(response)
        
        $('#vazao').attr('value', response.vazao) 
        $('#volume').attr('value',response.volume)

      });


      $(document).ready(function() {
        setInterval(function() {
          $.getJSON('/parametros', function(response){
            console.log(response)
            
            $('#vazao').attr('value', response.vazao) 
            $('#volume').attr('value',response.volume)
    
          });
        }, 5000);
      });


    })